각각의 파일 실행 방법
1.ray, gym 등 설치 환경 세팅(ray의 경우, 0.8.7 ver)
2.커맨드 환경에서 파일에 접근하여 python [파일명].py 입력
ex) 커맨드 창에 python ppo.py 입력
* inference.py, inference_2.py 파일의 경우, 학습을 모두 완료하여 checkpoint 파일이 생성되었을 때 checkpoint 경로를 설정하여 실행
